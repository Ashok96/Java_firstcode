package howard.edu.ood.hw2.collections;

public class ArrayStacks implements StackOperations {
	
	int thisstack[];
	int stackindex = 0;
	int globalsize;
	public ArrayStacks(int stacksize){
		globalsize = stacksize;
		thisstack = new int[stacksize];
		
	}
	
	public void push(int item){
		if (stackindex<globalsize){
			thisstack[stackindex] = item;
			stackindex += 1;
		}	
		else{
			DynamicStack ();
			thisstack[stackindex] = item;
			stackindex += 1;
		}
	
	}
	public boolean isEmpty(){
		
		if (stackindex == 0){
			return true;
		}
		else {
			return false;
		}
		
	}
	

	public int peek(){
		return thisstack[stackindex-1];
	}
	
	public int pop(){
		
		int lastelem = thisstack[stackindex-1];
		int randarr[] = new int[globalsize];
		for (int i = 0; i<stackindex-1;i++){
			randarr[i] = thisstack[i];
		}
		stackindex -- ;
		thisstack = randarr;
		return lastelem;
	}
	
	public String toString(){
		
		String expected = "";
		for (int i = 0; i<stackindex;i++){
			expected += thisstack[i]+" ";
		}
		String result = "top [ "+expected+"] bottom";
		return result;			
	}
	
	public void DynamicStack(){
		int stackmodified[] = new int[globalsize*globalsize];
		for (int i = 0; i<globalsize;i++ ){
			stackmodified[i] = thisstack[i];
		}
		globalsize *=globalsize;
		thisstack = stackmodified;
	}
	//top [ 5 2 8 ] bottom (stack with 3 elements)

}