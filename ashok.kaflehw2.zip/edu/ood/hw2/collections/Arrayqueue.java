package howard.edu.ood.hw2.collections;import java.util.*;

public class Arrayqueue implements queueoperations {
	int thisqueue[];
	int top;
	int bottom;
	int index;
	int newsize;
	
	public Arrayqueue(int size) {
		thisqueue = new int [size];
		top =0;
		bottom=0;
		index =0;
		
	}
	
	public void enqueue(int item) {
		if (index < newsize) {
			thisqueue[bottom]=item;
			bottom = (bottom + 1)%newsize;
			index ++;
		}
		else {
			Dynamicqueue();
			thisqueue[bottom]=item;
			bottom = (bottom + 1)%newsize;
			index ++;
			
		}
	}

	// Remove an element from the queue
	public int dequeue() {
		int removeitem;
		if (this.isEmpty ()) {
			throw new NoSuchElementException();
		}
		else {
			removeitem = thisqueue[top];
			top = (top+1)%newsize;
			index -=1;
		
		}
		return removeitem;
}

public boolean isEmpty() {
	return (index ==0);
	}

public int peek() {
	return thisqueue[top];
}

public void Dynamicqueue(){
	int newqueue[] = new int [newsize*2];
	for (int i = 0; i <index; i++) {
		newqueue[i]=thisqueue[i];
		top = (top+1)%newsize;
	}
	top =0;
	bottom =index;
	thisqueue = newqueue;
	newsize *=2;
}

public String toString(){
	String expected ="";
	String output =""; 
	for (int i = 0; i < index; i+=1) {
		expected +=thisqueue[i]+ " ";
	}
	output += "front ["+expected+"] back";
	return output;
	}
}


