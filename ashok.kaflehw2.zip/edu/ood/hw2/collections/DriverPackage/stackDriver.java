package howard.edu.ood.hw2.collections.DriverPackage;
import howard.edu.ood.hw2.collections.ArrayStacks;

public class stackDriver {
	public static void main(String args[]){
		ArrayStacks mystack =  new ArrayStacks(5);
		mystack.push(10);mystack.push(20);mystack.push(30);mystack.push(40);
		mystack.push(10);mystack.push(20);mystack.push(30);mystack.push(40);
		mystack.push(10);mystack.push(20);mystack.push(30);mystack.push(40);
		System.out.println(mystack.toString());
		System.out.println(mystack.isEmpty());
		System.out.println(mystack.peek());
		System.out.println(mystack.pop());
		System.out.println(mystack.pop());
	}

}
