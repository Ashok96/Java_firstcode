package howard.edu.ood.hw2.collections.DriverPackage;
import howard.edu.ood.hw2.collections.Arrayqueue;


public class queueDriver{
	public static void main(String args[]){
		Arrayqueue myqueue = new Arrayqueue(50);
		//to enqueue elements onto the stack
		for (int i = 0; i<20;i++){
			myqueue.enqueue(i);
		}
		
		System.out.println("Queue after enqueueing 20 items to it");
		System.out.println(myqueue.toString());
		//to dequeue elements from the stack
		System.out.println("Dequeueing following items: ");
		for (int i = 0; i< 5; i++){
			System.out.println(myqueue.dequeue());
		}
		System.out.println("Queue after 5 items being dequeued");
		System.out.println(myqueue.toString());

	
	}

}
